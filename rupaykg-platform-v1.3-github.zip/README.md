
# RupayKg Platform v1.3

Includes:
1) End-to-end OTP auth with JWT + refresh tokens
2) Digitally signed PDF reports linked to MRV hashes
3) Play Store & App Store ready mobile configuration

This version is submission-ready for pilots and audits.
