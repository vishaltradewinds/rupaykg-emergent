
from fastapi import APIRouter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
import hashlib

router = APIRouter()

@router.get("/reports/signed-pdf")
def signed_pdf(mrv_hash: str):
    path = "/tmp/signed_report.pdf"
    c = canvas.Canvas(path, pagesize=A4)
    c.drawString(80, 750, "RupayKg Signed Government Report")
    c.drawString(80, 720, f"MRV Hash: {mrv_hash}")
    signature = hashlib.sha256(mrv_hash.encode()).hexdigest()
    c.drawString(80, 690, f"Digital Signature: {signature}")
    c.save()
    return {"file": "signed_report.pdf", "signature": signature}
