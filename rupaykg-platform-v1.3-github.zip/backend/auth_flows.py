
from fastapi import APIRouter
import jwt, time, random

SECRET = "CHANGE_ME"
router = APIRouter()

@router.post("/auth/request-otp")
def request_otp(phone: str):
    otp = random.randint(100000, 999999)
    return {"otp": otp, "note": "Send via SMS gateway in production"}

@router.post("/auth/verify-otp")
def verify_otp(phone: str, otp: int):
    payload = {
        "phone": phone,
        "role": "citizen",
        "exp": int(time.time()) + 3600
    }
    token = jwt.encode(payload, SECRET, algorithm="HS256")
    return {"access_token": token}

@router.post("/auth/refresh")
def refresh_token(old_token: str):
    payload = jwt.decode(old_token, SECRET, algorithms=["HS256"], options={"verify_exp": False})
    payload["exp"] = int(time.time()) + 3600
    return {"access_token": jwt.encode(payload, SECRET, algorithm="HS256")}
